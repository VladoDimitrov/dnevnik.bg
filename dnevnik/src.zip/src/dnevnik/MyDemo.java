package dnevnik;

import java.util.stream.Collectors;

import Exceptions.InvalidStringException;
import Exceptions.NoLoggedUserException;
import Exceptions.UserNotFoundException;
import comparators.ArticleComparators;

public class MyDemo {
	
	public static void main(String[] args) {
		Main main = new Main();
		main.main(null);
	}
}
