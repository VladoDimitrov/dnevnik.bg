package dnevnik;

import java.util.Calendar;
import java.util.Date;

public class Comment {

	private final Article article;
	private final User user;
	private final Date date;
	private String commentText;
	private int likes;
	private int dislikes;

	Comment(User user, Article article, String commentText) {
		this.user = user;
		this.commentText = commentText;
		this.article = article;
		dislikes = 0;
		likes = 0;
		date = Calendar.getInstance().getTime();
	}

	public void thumbsUp() {
		likes++;
	}

	public void thumbsDown() {
		dislikes++;
	}

	@Override
	public String toString() {
		String comment = user.toString() + "\n" + date + "\n" + commentText + "\nDislikes: " + dislikes
				+ " Likes: " + likes;
		return comment;
	}

	public Article getArticle() {
		return article;
	}

	public User getUser() {
		return user;
	}

	public Date getDate() {
		return date;
	}

	public int getThumbsUp() {
		return likes;
	}

	public int getThumbsDown() {
		return dislikes;
	}
	
	public void edit(String text) {
		if (text!=null) {
			this.commentText = text;
		}
	}
	
}
