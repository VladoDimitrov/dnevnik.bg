//package dnevnik;
//
//import Exceptions.InvalidStringException;
//import Exceptions.NoLoggedUserException;
//import Exceptions.UserNotFoundException;
//
//public abstract class LoggedUser extends User { //LoggedUser nasledqva User, zashtoto e User, ne znam dali mi e dobra logikata, ama na testovete mi raboti
//	private static User loggedUser = null;
//	
//	
//	private LoggedUser(User user) throws InvalidStringException {
//		super(user);
//		if (user!=null) {
//			LoggedUser.loggedUser = user;
//		}
//	}
//	
//	
//	
//	
//	//vzimame lognatiqt 	user, ako nikoi ne e lognat, hvurlqme exception, che nqma lognat user
//	public static User getInstance() throws NoLoggedUserException {
//		if (loggedUser!=null)
//			return loggedUser;
//		throw new NoLoggedUserException("There is no logged user");
//	}
//	
//	//smenqme koi da e lognatiqt kato podavame drug user. AKo tozi user ne sushtestvuva, huvrlqme exception
//	public static void setLoggedUser(User user) throws UserNotFoundException {
//		if (AllUsers.getAllUsers().contains(user) || user==null)
//			loggedUser = user;
//		
//		else {
//			throw new UserNotFoundException("No such user exists, you cannot log him in!");
//		}
//	}
//}
