package Enums;

public enum SortArticlesEnum {
	BYREADCOUNT, BYDATEADDED, BYCOMMENTSCOUNT

}
