package dnevnik;

import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

public class Article {

	private final User author;
	private String title;
	private String mainText;
	private Stack<Comment> comments;
	private List<String> tags;
	private Date dateAdded;
	private int readCount;
	



	Article(User author, String title, String text, List<String> tags) {
		this.author = author;
		this.title = title;
		this.mainText = text;
		this.tags = tags;
		readCount = 0;
		dateAdded = Calendar.getInstance().getTime();
	}

	public void addComment(Comment comment) {
		this.comments.push(comment);
	}

	public void showComments() {
		int commentNum = 0;
		for (Comment comment : comments) {
			System.out.print(++commentNum + ": ");
			System.out.println(comment.toString());
		}
	}

	public User getAuthor() {
		return author;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(User user, String title) {
		if (user.equals((User) this.getAuthor()))
			this.title = title;
	}

	public String getMainText() {
		return mainText;
	}

	public void setMainText(User user, String mainText) {
		if (user.equals((User) this.getAuthor()))
			this.mainText = mainText;
	}

	public Stack<Comment> getComments() {
		return (Stack<Comment>) this.comments.clone();
	}

	public Date getDateAdded() {
		return dateAdded;
	}
	@Override
	public boolean equals(Object article) {
		return dateAdded.equals(((Article)article).getDateAdded());
	}
	public List<String> getTags() {
		return tags;
	}
	
	@Override
	public String toString() {
		String articleToString = (title + "\n\nAuthor: " + author.getUsername() + "; Added: " + dateAdded + "\n\n" + mainText + "\n\nTags: " + tags.toArray().toString());
		return articleToString;
	}
	
	
	public Set<Comment> sortCommentsByLikes() {
		TreeSet<Comment> result = new TreeSet<Comment>(new Comparator<Comment>() {
			@Override
			public int compare(Comment o1, Comment o2) {
				if(o1.getThumbsUp()==o2.getThumbsDown()) {
					return 1;
				}
				return -(o1.getThumbsUp()-o2.getThumbsUp());
			}
		});
		result.addAll(this.comments);
		return result;
	}

	public int getReadCount() {
		return readCount;
	}
	
}
