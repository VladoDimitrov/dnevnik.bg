package dnevnik;

import java.util.HashSet;
import java.util.Set;

import Exceptions.InvalidStringException;

public class RandomArticleGenerator {
	
	
	
	private static int randArticleNum = 1;
	
	private static String randArticleTitle = "Article " + randArticleNum++;
	
	private static String randArticleText = "This is a randomly generated article";
	
	private static User dnevnik ;
	
	private static Set<String> randTags = new HashSet<String>();
	
	
	public static Article generate() {
		
		
		return new Article (User.getDefaultUser(), randArticleTitle, randArticleText , randTags);
		
	}

}
