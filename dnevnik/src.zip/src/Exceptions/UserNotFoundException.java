package Exceptions;

public class UserNotFoundException extends Exception {


	
	public UserNotFoundException(String message) {
		super(message);
	}

	private static final long serialVersionUID = 4229491724009580114L;
    
}
