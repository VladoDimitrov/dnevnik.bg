package dnevnik;

import java.util.Date;
import java.util.Calendar;

public class demo {
	public static void main(String[] args) throws InterruptedException{

	Date date1 = Calendar.getInstance().getTime();
	Thread.sleep(1000);
	Date date2 = Calendar.getInstance().getTime();
	System.out.println(date2.compareTo(date1));
	
	
	
	
	}
}
