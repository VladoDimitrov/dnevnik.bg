//package dnevnik;
//
//import java.util.HashSet;
//import java.util.Scanner;
//import java.util.Set;
//
//public class Tag {
//
//	private static Set<Tag> allTags = new HashSet<Tag>();
//
//	private String tag;
//
//	public Tag(String tag) {
//		this.tag = tag;
//	}
//
//	public Tag getTag() {
//		return this;
//	}
//
//	public void newTag(String tag) {
//		if (tag.length() > 0 && !allTags.contains(new Tag(tag))) {
//			allTags.add(new Tag(tag));
//		}
//		
//	}
//	
//	public static Set<Tag> getTags(){
//		return new HashSet<Tag>(allTags);
//	}
//	
//	public static Set<Tag> tagsToArticle(){
//		System.out.println("Add tags to article? (y/n)");
//		String answer;
//		Scanner in = new Scanner(System.in);
//		answer = in.nextLine();
//		if (!answer.equalsIgnoreCase("n") && !answer.equalsIgnoreCase("y")) {
//			System.out.println("Please choose a valid option - y/n");
//			askTag();
//			
//		}
//	}
//	
//	private static Tag askTag() {
//		System.out.println("Add more tags? (y/n)");
//		String answer;
//		Scanner in = new Scanner(System.in);
//		answer = in.nextLine();
//		if (!answer.equalsIgnoreCase("n") && !answer.equalsIgnoreCase("y")) {
//			System.out.println("Please choose a valid option - y/n");
//			return askTag();
//			
//		}
//		return answer.equalsIgnoreCase("y") ? addTag() : null;
//		
//	}
//	private static Tag addTag() {
//		String newTag;
//		System.out.println("Please enter tag name");
//		Scanner in = new Scanner(System.in);
//		newTag = in.nextLine();
//		Tag tag = new Tag(newTag);
//		allTags.add(tag);
//		return tag;
//		
//	}
//	
//	public static String allTags() {
//		String all = "";
//		allTags.forEach(tag -> all.concat(tag.tag + " "));
//		return all;
//	}
//
//	@Override
//	public boolean equals(Object tagg) {
//
//		return this.tag.equalsIgnoreCase(((Tag) tagg).tag);
//	}
//}
