package dnevnik;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import Exceptions.NoArticleException;

public class AllArticles {

	private static Set<Article> allArticles = new HashSet<Article>();

	public static void addArticle(Article article) {
		if (article != null) {
			allArticles.add(article);
		}
	}

	public Set<Article> getAllArticles() {
		return new HashSet<Article>(allArticles);
	}

	public Set<Article> searchForWord(String wordToFind) throws NoArticleException {
		Set<Article> containingWord = new HashSet<Article>();
		for (Article article : allArticles) {
			if (article.getMainText().contains(wordToFind) || article.getTitle().contains(wordToFind)
					|| article.getTags().contains(wordToFind))
				containingWord.add(article);
		}
		if (containingWord.isEmpty()) throw new NoArticleException("No article contains this word");
		return containingWord;
	}
	
	public Set<Article> searchForWordInText(String wordToFind) throws NoArticleException {
		Set<Article> containingWord = new HashSet<Article>();
		for (Article article : allArticles) {
			if (article.getMainText().contains(wordToFind))
				containingWord.add(article);
		}
		if (containingWord.isEmpty()) throw new NoArticleException("No article text contains this word");
		return containingWord;
	}
	
	public Set<Article> searchForWordInTitle(String wordToFind) throws NoArticleException {
		Set<Article> containingWord = new HashSet<Article>();
		for (Article article : allArticles) {
			if (article.getTitle().contains(wordToFind))
				containingWord.add(article);
		}
		if (containingWord.isEmpty()) throw new NoArticleException("No article title contains this word");
		return containingWord;
	}
	
	public Set<Article> searchForWordInTags(String wordToFind) throws NoArticleException {
		Set<Article> containingWord = new HashSet<Article>();
		for (Article article : allArticles) {
			if (article.getTags().contains(wordToFind))
				containingWord.add(article);
		}
		if (containingWord.isEmpty()) throw new NoArticleException("No article contains this tag");
		return containingWord;
	}
	
	public Set<Article> getAllNotUsersArticles() throws NoArticleException {
		Set<Article> articles = new HashSet<Article>();
		for (Article x : 	allArticles) {
			if (x.getAuthor().getUsername().equals("Dnevnik.bg")) {
				articles.add(x);
			}
		}
		if (articles.isEmpty()) throw new NoArticleException("No articles that are not Users' are in this site ");
		return articles;
	}
	
//	public Set<Article> getAllArticlesFromToday() {
//		Set<Article> articles = new HashSet<Article>();
//		for (Article x : AllArticles.allArticles) {
//			if(x.getDateAdded().get(Calendar.DAY_OF_MONTH)==(Calendar.getInstance().get(Calendar.DAY_OF_MONTH))) {
//				 
//			}
//		}
//		return articles;
//	}
	
	public Set<Article> sortArticles(String byWhat){
		Set<Article> sortedArticles = new TreeSet<Article>();
		switch (byWhat.toLowerCase()) {
		case "byreadcount":
			sortedArticles = new TreeSet<Article>(ArticleComparators.byReadCount);
			break;
		case "bydateadded":
			sortedArticles = new TreeSet<Article>(ArticleComparators.byDateAdded);
			break;
		case "bycommentscount":
			sortedArticles = new TreeSet<Article>(ArticleComparators.byCommentsCount);
			break;
		default:
			break;
		}
		sortedArticles.addAll(allArticles);
		return sortedArticles;
	}
	
	
	
	private static class ArticleComparators {
		private static Comparator<Article> byReadCount = new Comparator<Article>() {
			@Override
			public int compare(Article a1, Article a2) {
				return a1.getReadCount() > a2.getReadCount() ? 1 : a2.getReadCount() > a1.getReadCount() ? -1 : 0;
			}			
		};
		private static Comparator<Article> byDateAdded = new Comparator<Article>() {
			@Override
			public int compare(Article a1, Article a2) {
				return a2.getDateAdded().compareTo(a1.getDateAdded());
			}			
		};
		private static Comparator<Article> byCommentsCount = new Comparator<Article>() {
			@Override
			public int compare(Article a1, Article a2) {
				return a1.getComments().size() > a2.getComments().size() ? 1 : a2.getComments().size() > a1.getComments().size() ? -1 : 0;
			}			
		};
	}
}
