package Exceptions;

public class InvalidStringException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5057456610639180976L;

	public InvalidStringException(String message) {
		super(message);
	}



}
