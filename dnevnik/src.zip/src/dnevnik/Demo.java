package dnevnik;

import java.lang.reflect.Type;
import com.google.gson.reflect.TypeToken;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.plaf.synth.SynthSpinnerUI;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Exceptions.InvalidStringException;
import Exceptions.NoArticleException;
import Exceptions.NoLoggedUserException;
import Exceptions.UserNotFoundException;
import Serializers.ArticleDeserializer;
import Serializers.ArticleSerializer;
import Serializers.CommentDeserializer;
import Serializers.CommentSerializer;
import Serializers.UserDeserializer;
import Serializers.UserSerializer;

public class Demo {
	
	private static User user;

	static void saveCommentsIntoFile(String filePath) {
		Set<Comment> comments = AllComments.getAllComments();
		Gson gson = new GsonBuilder().registerTypeAdapter(Comment.class, new CommentSerializer()).setPrettyPrinting()
				.create();
		try {
			FileWriter writer = new FileWriter(filePath);
			String result = gson.toJson(comments);
			writer.write(result);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	static void loadComments(String filePath) {
		Gson gson = new GsonBuilder().registerTypeAdapter(Comment.class, new CommentDeserializer()).create();
		Set<Comment> comments = new HashSet<Comment>();
		try {
			Reader reader = new FileReader(filePath);
			Type listType = new TypeToken<HashSet<Comment>>() {
			}.getType();
			comments = (Set<Comment>) gson.fromJson(reader, listType);
			AllComments.setAllComments(comments);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	static void loadArticles(String filePath) {
		Gson gson = new GsonBuilder().registerTypeAdapter(Article.class, new ArticleDeserializer()).create();
		Set<Article> articles = new HashSet<Article>();
		try {
			Reader reader = new FileReader(filePath);
			Type listType = new TypeToken<HashSet<Article>>() {
			}.getType();
			articles = (Set<Article>) gson.fromJson(reader, listType);
			AllArticles.setAllArticles(articles);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static void saveArticleIntoFile(String filePath) {
		Set<Article> articles = AllArticles.getAllArticles();
		Gson gson = new GsonBuilder().registerTypeAdapter(Article.class, new ArticleSerializer()).setPrettyPrinting()
				.create();
		try {
			FileWriter writer = new FileWriter(filePath);
			String result = gson.toJson(articles);
			writer.write(result);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static void saveUsersIntoFile(String filePath) {
		Set<User> users = AllUsers.getAllUsers();
		Gson gson = new GsonBuilder().registerTypeAdapter(User.class, new UserSerializer()).setPrettyPrinting()
				.create();

		try {
			FileWriter writer = new FileWriter(filePath);
			String result = gson.toJson(users);
			writer.write(result);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	static void loadUsers(String filePath) {
		Set<User> users = new HashSet<User>();
		Gson gson = new GsonBuilder().registerTypeAdapter(User.class, new UserDeserializer()).setPrettyPrinting()
				.create();

		try {
			FileReader reader = new FileReader(filePath);
			Type listType = new TypeToken<HashSet<User>>() {
			}.getType();
			users = (Set<User>) gson.fromJson(reader, listType);
			if (users != null)
				for (User x : users) {
					AllUsers.register(x);
				}
		} catch (IOException e) {
			e.printStackTrace();
		}
//		if (users!=null) {
//			for (User x : users) {
//				if (x.isLogged()) {
//					try {
//						LoggedUser.setLoggedUser(x);
//					} catch (UserNotFoundException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//				}
//			}
//		}
	}

	public static void main(String[] args) {
		loadArticles("src\\articles.json");
		loadUsers("src\\\\users1.json");
		loadComments("src\\comments2.json");

		System.out.println(AllArticles.getAllArticles().size());
		System.out.println(AllUsers.getAllUsers().size());
		System.out.println(AllComments.getAllComments().size());

		for (Article x : AllArticles.getAllArticles()) {
			try {
				x.setAuthor(AllUsers.getUserByUsername(x.getAuthorName()));
			} catch (UserNotFoundException | InvalidStringException e) {
				System.out.println("ima greshka nqkva!");
				e.printStackTrace();
			}

		}

//		for (Comment x : AllComments.getAllComments()) {
//			int articleIndex = x.getArticleID();
//			x.setArticle(articleIndex);
//			String username = x.getUsername();
//			x.setUser(username);
//		}

		for (User u : AllUsers.getAllUsers()) {
			List<Integer> articles = new ArrayList<Integer>();
			for (Article a : AllArticles.getAllArticles()) {
				if (a.getAuthor().equals(u))
					articles.add(a.getID());
			}
			int[] arrayArticles = new int[articles.size()];
			for (int i = 0; i < articles.size(); i++)
				arrayArticles[i] = articles.get(i);
			u.setArticlesID(arrayArticles);

			List<Integer> comments = new ArrayList<Integer>();
			for (Comment c : AllComments.getAllComments()) {
				if (c.getUser().equals(u))
					comments.add(c.getCommentID());
			}
			int[] arrayComments = new int[comments.size()];
			for (int i = 0; i < comments.size(); i++)
				arrayComments[i] = comments.get(i);
			u.setComments(arrayComments);

		}

		for (User u : AllUsers.getAllUsers()) {
			for (Integer i : u.getArticlesID()) {
				u.setArticleByID(i);
			}

		}
		// for (Article a : AllArticles.getAllArticles()) {
		// a.setComments(comments2);
		// }

		// for (User u : AllUsers.getAllUsers()) {
		// //System.out.println(u.getCommentsID());
		// System.out.println(u.getUsername());
		// System.out.println(u.getArticlesID());
		// //System.out.println(u.getArticles());
		// System.out.println(u.getCommentsID());
		// }

//		for (Article a : AllArticles.getAllArticles()) {
//			System.out.println(a.getAuthor().getUsername());
//			System.out.println(a.getComments());
//			System.out.println(a.getTags());
//		}
		
		
		try {
			AllUsers.register(new User("Zdravenqka", "1312"));
			AllUsers.register(new User("Teodor", "12345"));
			AllUsers.register(new User("Vlado", "asasas"));
			user = AllUsers.logIn("Zdravenqka", "1312");
			user.addArticle("Nqkakvo zaglavie", "Dosta qk tekst!", "tag1 tag2 tag3");
			user = AllUsers.logOut();
			user = AllUsers.logIn("Teodor", "12345");
			user.addComment(1, "Dosta qk komentar!");
			user = AllUsers.logOut();
			user = AllUsers.logIn("Vlado", "asasas");
			user.addComment(1, "Drug dosta qk!");
			
		} catch (InvalidStringException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoLoggedUserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// addArticle test
		// LoggedUser.getInstance().addArticle( "Nqkvo zaglavie", "Trimata bratq i
		// zlatnata qbulka-BG variant", "");
		// LoggedUser.getInstance().addArticle("Novinite dnes","Nqkakuv tekst", "");
		// LoggedUser.getInstance().addArticle("Piq i pusha", "Dvama goli i edin bez
		// gashti", "");
		// Article article = new Article(pesho, "Zaglavie", "Nqkakuv tekst", new
		// HashSet<String>());
		// System.out.println(article.getPreview());
		// LoggedUser.getInstance().addArticle("Sportyt dnes", "Boiko Borisov vkara gol
		// na Botev Lukovit", "");
		// LoggedUser.getInstance().addComment(1, "Svetut mi e v krakara!");
		// LoggedUser.getInstance().addArticle("asasa", "text", "dada das ewq");
		// LoggedUser.getInstance().addComment(2, "Svetut mi e v krakara!");
		// LoggedUser.getInstance().addComment(3, "Svetut mi e v krakara!");
		// LoggedUser.getInstance().addComment(4, "Svetut mi e v krakara!");
		// LoggedUser.getInstance().addComment(5, "Svetut mi e v krakara!");
		// LoggedUser.getInstance().addComment(6, "Svetut mi e v krakara!");
		// LoggedUser.getInstance().addArticle("Novo zaglavie", "nov tekst", "pesho
		// gosho ivan");
		// LoggedUser.getInstance().addArticle("Novo zaglavie", "nov tekst", "pesho
		// gosho ivan");

		// System.out.println(AllArticles.getAllArticles().size());

		// System.out.println(AllComments.getAllComments().size());

		// getAllArticles test
		// User stefan = new User("Stefan", "11");
		// v momenta stefan ne se e registriral, a vsushnost moje da pishe statii i
		// komentari... trqbva da se opravi
		// trqbva da go izmislim nqkaksi, 4e da ne stava tva, neshto kato proverka pri
		// pisaneto na statiite i komentarite dali
		// user-a deto pishe e v AllUsers, zashtoto nali tam sa vsichkite user-i, i
		// kogato se regva se dobavq tam (class AllUsers)
		// stefan.addArticle( "Nenormalnik!", "Toq parkira nepravilno, ubiite go s
		// tuhli!");

		// System.out.println(AllArticles.getAllArticles());
		// System.out.println();
		// System.out.println("_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*");

		// searchForWord test
		// try {
		// System.out.println(AllArticles.searchForWord("gol"));
		// } catch (NoArticleException e) {
		// System.out.println(e.getMessage());
		// }

		// logout test
		// try {
		// AllUsers.logOut();
		// } catch (UserNotFoundException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		// try {
		// LoggedUser.getInstance().addComment(2, "ebasi maikata, mnogo qka statiq!");
		// LoggedUser.getInstance().addComment(3, "pak mnogo qka startiq!");
		// } catch (InvalidStringException | NoLoggedUserException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		saveUsersIntoFile("src\\users2.json");
		saveCommentsIntoFile("src\\comments1.json");

		System.out.println("-------------------");
		System.out.println(AllUsers.getAllUsers());

		saveArticleIntoFile("src\\articles1.json");
	}
}
