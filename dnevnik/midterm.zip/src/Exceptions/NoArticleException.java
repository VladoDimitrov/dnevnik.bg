package Exceptions;

public class NoArticleException extends Exception {

	/**
	 * 
	 */
	
	
	private static final long serialVersionUID = -8705524821489265528L;

	public NoArticleException(String message) {
		super(message);
		
	}

}
