package dnevnik;

import java.util.HashSet;
import java.util.Set;
import java.util.Stack;

import Exceptions.InvalidStringException;
import Exceptions.UserNotFoundException;

class AllUsers {
	private static Set<User> allUsers = new HashSet<User>();
	

	void Register(User newUser) {
		if (newUser != null && !allUsers.contains(newUser)) {
			allUsers.add(newUser);
		}
	}
	
	public Set<User> getAllUsers() {
		return new HashSet<User>(this.allUsers);
	}
	
	public void logIn(String username, String password) {
		if (username!=null && username.trim().length()>2) {
			for (User user : this.allUsers) {
				if (user.getUsername().equals(username) && user.getPass().equals(password)) {
					if (!user.isLogged()) {
						user.setLogged(true);
						System.out.println("You are now logged in as: "+user.getUsername());
						break;
					} else {
						System.out.println("You are already logged in as this user!");
					}
				} else {
					System.out.println("Invalid username or password!");
				}
			}
		}
	}
	
	public Stack<Article> getAllArticlesFromUser(String username) throws InvalidStringException, UserNotFoundException {
		if (username!=null && username.trim().length()>0) {
			for (User x : AllUsers.allUsers) {
				if (x.getUsername().equals(username)) {
					return x.getArticles();
				}
			}
		} else {
			throw new InvalidStringException("Invalid string!");
		}
		throw new UserNotFoundException("User not found");	
	}
	
	public Stack<Comment> getAllCommentsFromUser(String username) throws InvalidStringException, UserNotFoundException {
		if (username!=null && username.trim().length()>0) {
			for (User x : AllUsers.allUsers) {
				if (x.getUsername().equals(username)) {
					return x.getComments();
				}
			}
		} else {
			throw new InvalidStringException("Invalid string!");
		}
		throw new UserNotFoundException("No such user");	
	}
	
	
}